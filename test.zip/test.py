def lambda_function(event,context):
    print("Hello World ")
